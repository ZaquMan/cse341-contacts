# How to run it

Run npm install and npm start from the backend folder in the terminal

Test the endpoints in the routes.rest file with Rest Client or another similar tool.

## About this code

This code came from the lesson 4 prove solution. There may be slight modifications to it, but it will be very similar, if not exactly the same.

## Class Activity Purpose

The purpose of this activity is to get practice adding error handling and data validation to our node applications.
